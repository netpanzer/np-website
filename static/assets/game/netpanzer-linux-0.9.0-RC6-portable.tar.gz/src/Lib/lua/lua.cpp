#include "lua/lua.hpp"

lua_State * globalLuaState;
